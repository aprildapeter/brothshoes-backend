<a href="/">
    <img src="/broth_logo.svg" alt="LOGO"> 
</a><?php /**PATH C:\laragon\www\brothshoes\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>