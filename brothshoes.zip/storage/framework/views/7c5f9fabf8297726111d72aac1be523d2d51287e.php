<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!-- <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []]); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
    </div> -->

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <!-- <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg"> -->
            <div class="grid grid-cols-1 md:grid-cols-4">

                <div class="p-6">
                    <div class="mt-8 bg-blue-500 dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                        <div class="ml-2 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">

                            <div class="flex items-center p-2">
                                <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4 11H10C10.2652 11 10.5196 10.8946 10.7071 10.7071C10.8946 10.5196 11 10.2652 11 10V4C11 3.73478 10.8946 3.48043 10.7071 3.29289C10.5196 3.10536 10.2652 3 10 3H4C3.73478 3 3.48043 3.10536 3.29289 3.29289C3.10536 3.48043 3 3.73478 3 4V10C3 10.2652 3.10536 10.5196 3.29289 10.7071C3.48043 10.8946 3.73478 11 4 11ZM14 11H20C20.2652 11 20.5196 10.8946 20.7071 10.7071C20.8946 10.5196 21 10.2652 21 10V4C21 3.73478 20.8946 3.48043 20.7071 3.29289C20.5196 3.10536 20.2652 3 20 3H14C13.7348 3 13.4804 3.10536 13.2929 3.29289C13.1054 3.48043 13 3.73478 13 4V10C13 10.2652 13.1054 10.5196 13.2929 10.7071C13.4804 10.8946 13.7348 11 14 11ZM4 21H10C10.2652 21 10.5196 20.8946 10.7071 20.7071C10.8946 20.5196 11 20.2652 11 20V14C11 13.7348 10.8946 13.4804 10.7071 13.2929C10.5196 13.1054 10.2652 13 10 13H4C3.73478 13 3.48043 13.1054 3.29289 13.2929C3.10536 13.4804 3 13.7348 3 14V20C3 20.2652 3.10536 20.5196 3.29289 20.7071C3.48043 20.8946 3.73478 21 4 21ZM17 21C19.206 21 21 19.206 21 17C21 14.794 19.206 13 17 13C14.794 13 13 14.794 13 17C13 19.206 14.794 21 17 21Z" fill="#3B82F6" />
                                </svg>

                                <div class="ml-4 text-lg leading-7 font-semibold">
                                    <h5>Total Category</h5>
                                </div>
                            </div>

                            <div class="ml-20 mb-5">
                                <div class="mt-2 text-gray-600 dark:text-gray-400 font-bold text-lg">
                                    <h1>12</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-6">
                    <div class="mt-8 bg-green-500 dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                        <div class="ml-2 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">

                            <div class="flex items-center p-2">
                                <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 2H3C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V21C2 21.2652 2.10536 21.5196 2.29289 21.7071C2.48043 21.8946 2.73478 22 3 22H7C7.26522 22 7.51957 21.8946 7.70711 21.7071C7.89464 21.5196 8 21.2652 8 21V3C8 2.73478 7.89464 2.48043 7.70711 2.29289C7.51957 2.10536 7.26522 2 7 2V2ZM5 21C4.60444 21 4.21776 20.8827 3.88886 20.6629C3.55996 20.4432 3.30362 20.1308 3.15224 19.7654C3.00087 19.3999 2.96126 18.9978 3.03843 18.6098C3.1156 18.2219 3.30608 17.8655 3.58579 17.5858C3.86549 17.3061 4.22186 17.1156 4.60982 17.0384C4.99778 16.9613 5.39991 17.0009 5.76537 17.1522C6.13082 17.3036 6.44318 17.56 6.66294 17.8889C6.8827 18.2178 7 18.6044 7 19C7 19.5304 6.78929 20.0391 6.41421 20.4142C6.03914 20.7893 5.53043 21 5 21ZM7 12H3V3H7V12ZM6 19C6 19.1978 5.94135 19.3911 5.83147 19.5556C5.72159 19.72 5.56541 19.8482 5.38268 19.9239C5.19996 19.9996 4.99889 20.0194 4.80491 19.9808C4.61093 19.9422 4.43275 19.847 4.29289 19.7071C4.15304 19.5673 4.0578 19.3891 4.01921 19.1951C3.98063 19.0011 4.00043 18.8 4.07612 18.6173C4.15181 18.4346 4.27998 18.2784 4.44443 18.1685C4.60888 18.0586 4.80222 18 5 18C5.26522 18 5.51957 18.1054 5.70711 18.2929C5.89464 18.4804 6 18.7348 6 19ZM14 2H10C9.73478 2 9.48043 2.10536 9.29289 2.29289C9.10536 2.48043 9 2.73478 9 3V21C9 21.2652 9.10536 21.5196 9.29289 21.7071C9.48043 21.8946 9.73478 22 10 22H14C14.2652 22 14.5196 21.8946 14.7071 21.7071C14.8946 21.5196 15 21.2652 15 21V3C15 2.73478 14.8946 2.48043 14.7071 2.29289C14.5196 2.10536 14.2652 2 14 2V2ZM12 21C11.6044 21 11.2178 20.8827 10.8889 20.6629C10.56 20.4432 10.3036 20.1308 10.1522 19.7654C10.0009 19.3999 9.96126 18.9978 10.0384 18.6098C10.1156 18.2219 10.3061 17.8655 10.5858 17.5858C10.8655 17.3061 11.2219 17.1156 11.6098 17.0384C11.9978 16.9613 12.3999 17.0009 12.7654 17.1522C13.1308 17.3036 13.4432 17.56 13.6629 17.8889C13.8827 18.2178 14 18.6044 14 19C14 19.5304 13.7893 20.0391 13.4142 20.4142C13.0391 20.7893 12.5304 21 12 21ZM14 12H10V3H14V12ZM13 19C13 19.1978 12.9414 19.3911 12.8315 19.5556C12.7216 19.72 12.5654 19.8482 12.3827 19.9239C12.2 19.9996 11.9989 20.0194 11.8049 19.9808C11.6109 19.9422 11.4327 19.847 11.2929 19.7071C11.153 19.5673 11.0578 19.3891 11.0192 19.1951C10.9806 19.0011 11.0004 18.8 11.0761 18.6173C11.1518 18.4346 11.28 18.2784 11.4444 18.1685C11.6089 18.0586 11.8022 18 12 18C12.2652 18 12.5196 18.1054 12.7071 18.2929C12.8946 18.4804 13 18.7348 13 19ZM21 2H17C16.7348 2 16.4804 2.10536 16.2929 2.29289C16.1054 2.48043 16 2.73478 16 3V21C16 21.2652 16.1054 21.5196 16.2929 21.7071C16.4804 21.8946 16.7348 22 17 22H21C21.2652 22 21.5196 21.8946 21.7071 21.7071C21.8946 21.5196 22 21.2652 22 21V3C22 2.73478 21.8946 2.48043 21.7071 2.29289C21.5196 2.10536 21.2652 2 21 2V2ZM19 21C18.6044 21 18.2178 20.8827 17.8889 20.6629C17.56 20.4432 17.3036 20.1308 17.1522 19.7654C17.0009 19.3999 16.9613 18.9978 17.0384 18.6098C17.1156 18.2219 17.3061 17.8655 17.5858 17.5858C17.8655 17.3061 18.2219 17.1156 18.6098 17.0384C18.9978 16.9613 19.3999 17.0009 19.7654 17.1522C20.1308 17.3036 20.4432 17.56 20.6629 17.8889C20.8827 18.2178 21 18.6044 21 19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21ZM21 12H17V3H21V12ZM20 19C20 19.1978 19.9414 19.3911 19.8315 19.5556C19.7216 19.72 19.5654 19.8482 19.3827 19.9239C19.2 19.9996 18.9989 20.0194 18.8049 19.9808C18.6109 19.9422 18.4327 19.847 18.2929 19.7071C18.153 19.5673 18.0578 19.3891 18.0192 19.1951C17.9806 19.0011 18.0004 18.8 18.0761 18.6173C18.1518 18.4346 18.28 18.2784 18.4444 18.1685C18.6089 18.0586 18.8022 18 19 18C19.2652 18 19.5196 18.1054 19.7071 18.2929C19.8946 18.4804 20 18.7348 20 19Z" fill="#10b981" />
                                </svg>

                                <div class="ml-4 text-lg leading-7 font-semibold">
                                    <h5>Total Product</h5>
                                </div>
                            </div>

                            <div class="ml-20 mb-5">
                                <div class="mt-2 text-gray-600 dark:text-gray-400 font-bold text-lg">
                                    <h1>12</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-6">
                    <div class="mt-8 bg-yellow-500 dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                        <div class="ml-2 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">

                            <div class="flex items-center p-2">
                                <svg width="50" height="50" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3 14C3 14 2 14 2 13C2 12 3 9 8 9C13 9 14 12 14 13C14 14 13 14 13 14H3ZM8 8C8.79565 8 9.55871 7.68393 10.1213 7.12132C10.6839 6.55871 11 5.79565 11 5C11 4.20435 10.6839 3.44129 10.1213 2.87868C9.55871 2.31607 8.79565 2 8 2C7.20435 2 6.44129 2.31607 5.87868 2.87868C5.31607 3.44129 5 4.20435 5 5C5 5.79565 5.31607 6.55871 5.87868 7.12132C6.44129 7.68393 7.20435 8 8 8V8Z" fill="#f59e0b" />
                                </svg>

                                <div class="ml-4 text-lg leading-7 font-semibold">
                                    <h5>Total User</h5>
                                </div>
                            </div>

                            <div class="ml-20 mb-5">
                                <div class="mt-2 text-gray-600 dark:text-gray-400 font-bold text-lg">
                                    <h1>12</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-6">
                    <div class="mt-8 bg-red-500 dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                        <div class="ml-2 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">

                            <div class="flex items-center p-2">
                                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.36594 0C9.3681 0 10.2308 0.799805 10.4226 1.90527L10.5533 3.125H47.2152C48.9843 3.125 50.396 5.10254 49.8993 7.0957L45.1935 25.8496C44.8536 27.1973 43.7556 28.125 42.5094 28.125H14.8757L15.6774 32.8125H42.5268C43.6859 32.8125 44.6183 33.8574 44.6183 35.1562C44.6183 36.4551 43.6859 37.5 42.5268 37.5H13.8648C12.9411 37.5 12.0783 36.6992 11.8866 35.5957L6.63523 4.6875H2.09148C0.93681 4.6875 0 3.6377 0 2.34375C0 1.0498 0.93681 0 2.09148 0H8.36594ZM11.1546 45.3125C11.1546 42.7246 13.0282 40.625 15.3375 40.625C17.6469 40.625 19.5205 42.7246 19.5205 45.3125C19.5205 47.9004 17.6469 50 15.3375 50C13.0282 50 11.1546 47.9004 11.1546 45.3125ZM44.6183 45.3125C44.6183 47.9004 42.7447 50 40.4354 50C38.126 50 36.2524 47.9004 36.2524 45.3125C36.2524 42.7246 38.126 40.625 40.4354 40.625C42.7447 40.625 44.6183 42.7246 44.6183 45.3125Z" fill="#ef4444" />
                                </svg>

                                <div class="ml-4 text-lg leading-7 font-semibold">
                                    <h5>Total Transaksi</h5>
                                </div>
                            </div>

                            <div class="ml-20 mb-5">
                                <div class=" text-gray-600 dark:text-gray-400 font-bold text-lg">
                                    <h1>12</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- </div> -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\brothshoes\resources\views/dashboard.blade.php ENDPATH**/ ?>